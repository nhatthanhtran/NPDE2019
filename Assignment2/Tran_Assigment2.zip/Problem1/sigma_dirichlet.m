function funSigma = sigma_dirichlet()
funSigma = @(x) abs(x-1/2) + 1;
end

