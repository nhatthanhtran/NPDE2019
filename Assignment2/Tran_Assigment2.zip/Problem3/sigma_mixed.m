function funSigma = sigma_mixed()
funSigma = @(x) 1;
end

