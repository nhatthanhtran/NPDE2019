function funForce = force_mixed()
funForce = @(x) -4*exp(2.*x);
end

