function funSigma = sigma_dn()
funSigma = @(x) 1/2;
end

